#pragma once

#define fmtc_VERSION     30
#define fmtc_PLUGIN_NAME "fmtconv"
#define fmtc_NAMESPACE   "fmtc"
