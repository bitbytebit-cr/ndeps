SplitChannels
=============

.. function::   SplitChannels(anode clip)
   :module: std

   SplitChannels returns each audio channel of the input as
   a separate clip.
