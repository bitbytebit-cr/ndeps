RemoveFrameProps
================

.. function:: RemoveFrameProps(vnode clip[, string props[]])
   :module: std

   Returns *clip* but with all the frame properties named in
   *props* removed. If *props* is unset them all frame properties
   are removed.
