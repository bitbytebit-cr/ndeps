ClipInfo
========

.. function:: ClipInfo(vnode clip[, int alignment=7, int scale=1]])
   :module: text

   Prints information about the *clip*, such as the format and framerate.

   This is a convenience function for *Text*.
