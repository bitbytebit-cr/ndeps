# mvsfunc

mawen1250's VapourSynth functions

## How to install

If you have the old `mvsfunc.py` module installed on your system,
remove that from your system first. Otherwise, it might create conflicts and cause problems.

Install `mvsfunc` with the following command:
```sh
$ pip3 install git+https://github.com/HomeOfVapourSynthEvolution/mvsfunc
```
