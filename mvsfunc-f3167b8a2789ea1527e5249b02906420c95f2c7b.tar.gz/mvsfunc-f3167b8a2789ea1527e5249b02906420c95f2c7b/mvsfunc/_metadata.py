"""mawen1250's VapourSynth functions"""

__version__ = '11'

__author__ = 'mawen1250 <mawen1250@gmail.com>'
__maintainer__ = __author__

__author_name__, __author_email__ = [x[:-1] for x in __author__.split('<')]
__maintainer_name__, __maintainer_email__ = [x[:-1] for x in __maintainer__.split('<')]

if __name__ == '__github__':
    print(__version__)
