#include "assertive.h"
#include <VSScript4.h>
#include <VapourSynth4.h>
#include <VSHelper4.h>
#include <climits>
#include <cstdint>
#include <cstdarg>
#include <cstring>
#include <cstdlib>
#include <wchar.h>
#include <cstdio>
#include <atomic>
#include <algorithm>
#include <new>
#include <chrono>
#include <thread>
#include <string>
#include <fstream>
#include <vector>
#include "ss.h"
namespace avs {
#include <avisynth.h>
}
#include "avfspfm.h"
#include "xxfs.h"
#include "avfs.h"
#include "vsfs.h"
#include "videoinfoadapter.h"
#include "../common/fourcc.h"
#include "../common/wave.h"
#include "../common/vsutf16.h"
using namespace vsh;