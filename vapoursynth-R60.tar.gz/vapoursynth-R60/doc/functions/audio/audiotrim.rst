AudioTrim
=========

.. function::   AudioTrim(anode clip[, int first=0, int last, int length])
   :module: std
   
   AudioTrim performs exactly the same operation on audio clips but the unit is
   obviously samples instead of frames.

   In Python, std.AudioTrim can also be invoked by :ref:`slicing a clip <pythonreference>`.
