SetAudioCache
=============

.. function:: SetAudioCache(anode clip[, int mode, int fixedsize, int maxsize, int historysize])
   :module: std

   see SetVideoCache
