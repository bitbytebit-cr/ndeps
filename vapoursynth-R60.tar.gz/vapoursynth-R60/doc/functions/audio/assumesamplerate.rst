AssumeSampleRate
================

.. function::   AssumeSampleRate(anode clip[, anode src, int samplerate])
   :module: std
