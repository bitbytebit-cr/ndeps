FrameNum
========

.. function:: FrameNum(vnode clip[, int alignment=7, int scale=1])
   :module: text

   Prints the current frame number.

   This is a convenience function for *Text*.
