FrameProps
==========

.. function:: FrameProps(vnode clip[, string props=[], int alignment=7, int scale=1])
   :module: text

   Prints all properties attached to the frames, or if the *props* array is
   given only those properties.

   This is a convenience function for *Text*.
