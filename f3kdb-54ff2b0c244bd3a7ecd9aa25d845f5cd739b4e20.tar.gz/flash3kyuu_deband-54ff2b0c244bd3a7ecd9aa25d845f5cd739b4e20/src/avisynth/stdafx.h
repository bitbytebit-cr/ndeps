// Just a stub
#include "../stdafx.h"