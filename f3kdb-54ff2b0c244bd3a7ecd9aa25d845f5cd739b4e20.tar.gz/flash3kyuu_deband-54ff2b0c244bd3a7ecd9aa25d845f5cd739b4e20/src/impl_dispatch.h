#pragma once

#include "core.h"

extern const process_plane_impl_t** process_plane_impls[];

#define DITHER_CONTEXT_BUFFER_SIZE 8192

#define CONTEXT_BUFFER_SIZE DITHER_CONTEXT_BUFFER_SIZE
