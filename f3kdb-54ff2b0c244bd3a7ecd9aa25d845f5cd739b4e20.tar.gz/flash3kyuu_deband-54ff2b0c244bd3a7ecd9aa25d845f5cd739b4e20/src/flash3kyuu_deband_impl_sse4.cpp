#include "stdafx.h"

#include <smmintrin.h>

#include "flash3kyuu_deband_sse_base.h"

#define DECLARE_IMPL_SSE4
#include "impl_dispatch_decl.h"
