# fvsfunc
Small collection of VapourSynth functions I used at least once.
Most are simple wrappers or ports of AviSynth functions.
